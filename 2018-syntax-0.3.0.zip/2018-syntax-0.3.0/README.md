# New, Fresh Syntax Theme to try in Year 2018  👍  📦  🎉 !

# **BOLD** `h1` ~ `h6` Support in Markdown
![](https://imgur.com/nJsWri3.jpg)

# Awesome **BOLD** Keywords
![](https://imgur.com/KbBYgSR.jpg)

# Not a big fan of **SEMICOLONS** & **COMMA** ?
![](https://imgur.com/xtfiLE2.jpg)

They now have 50% brightness !

# **this**, **global object**, **keyword** support for JS !
![](https://imgur.com/4gNFkVt.jpg)

They now have 50% brightness !

# **$variables** support that works out of the box

![](https://imgur.com/3QpfcxZ.jpg)

# Be the first to try font-smoothing !
![](https://imgur.com/B78yRYi.jpg)

# Additional Support for different syntax

![](https://imgur.com/ljvgjRY.jpg)

# Any Suggestions, create an issue today !
[![](https://imgur.com/ruXOvMn.jpg)](https://github.com/alxtz/2018-syntax/issues)
